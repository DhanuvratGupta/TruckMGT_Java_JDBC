package org.example;

import javax.naming.Name;
import java.sql.*;

public class TruckServies {
    public Connection con;

    public void addTruck(Trucks truck)throws SQLException
    {
        System.out.println("IN");
        String sql="insert into trucks(name1,model,capacity,driver_name) values(?,?,?,?)";

            con=ConnectionDetails.getConnection();
            PreparedStatement pres=con.prepareStatement(sql);
            pres.setString(1,truck.getName());
            pres.setString(2,truck.getModel());
            pres.setInt(3,truck.getCapacity());
            pres.setString(4,truck.getDriver_name());
            int update=pres.executeUpdate();
            System.out.println("Row Inserted: "+update);



    }
    public Trucks getTruckById(int id)
    {
        Trucks truck=new Trucks();
        String sql="Select * from trucks where id=id";
        try{
            Statement s= con.createStatement();
            ResultSet ans=s.executeQuery(sql);
            if(ans.next())
            {
                truck.setId(ans.getInt("id"));
                truck.setModel(ans.getString("model"));
                truck.setName(ans.getString("name1"));
                truck.setCapacity(ans.getInt("capacity"));
                truck.setDriver_name(ans.getString("driver_name"));
            }
        }
        catch (Exception e)
        {

        }
        return truck;
    }
    public void updateTruck(Trucks truck) throws SQLException {
        String sql="update table trucks set name=?, model=?, capacity=?, driver_name=?, where id=?";

        PreparedStatement pres=con.prepareStatement(sql);
        pres.setString(1,truck.getName());
        pres.setString(2,truck.getModel());
        pres.setInt(3,truck.getCapacity());
        pres.setString(4,truck.getDriver_name());
        pres.setInt(5,truck.getId());
        int update=pres.executeUpdate();
        System.out.println("row updated");
    }
    public void getAllTrucks() throws SQLException {
        String sql="Select * from trucks";
        Connection co=ConnectionDetails.getConnection();
        Statement s= co.createStatement();
        ResultSet ans=s.executeQuery(sql);
        while(ans.next())
        {
            System.out.println(ans.getInt("id")+" "+
            ans.getString("model")+" "+
            ans.getString("name1")+" "+
            ans.getInt("capacity")+" "+
            ans.getString("driver_name"));
        }


    }
}
