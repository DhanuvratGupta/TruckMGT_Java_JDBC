package org.example;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * Hello world!
 *
 */
public class App 
{

    public static void main( String[] args) throws SQLException {
      //Trucks truck=new Trucks(1,"rahul","TATA",2000,"Abhishek");
      TruckServies Ts=new TruckServies();
      /*Ts.addTruck(truck);
      Trucks T=Ts.getTruckById(1);*/
      Ts.getAllTrucks();
    }
}
