package org.example;

public class Trucks {
       private int id;
       private String name1;
       private String model;
       private int capacity;
       private String driver_name;
    public Trucks(){

    }
    public Trucks(int id, String name, String model, int capacity, String driver_name) {
        this.id = id;
        this.name1 = name;
        this.model = model;
        this.capacity = capacity;
        this.driver_name = driver_name;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name1;
    }

    public String getModel() {
        return model;
    }

    public int getCapacity() {
        return capacity;
    }

    public String getDriver_name() {
        return driver_name;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name1 = name;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public void setCapacity(int capacity) {
        this.capacity = capacity;
    }

    public void setDriver_name(String driver_name) {
        this.driver_name = driver_name;
    }
}
